"""
Configure OpenTelemetry.
"""
import logging
from opentelemetry import metrics
from opentelemetry import trace
from opentelemetry._logs import set_logger_provider
 
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
 
from opentelemetry.sdk.metrics import MeterProvider
 
from opentelemetry.sdk.metrics.export import (
    PeriodicExportingMetricReader,
)
 
from opentelemetry.sdk.trace import TracerProvider
 
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
)

from opentelemetry.sdk._logs import (
    LoggerProvider,
    LoggingHandler,
)
from opentelemetry.sdk._logs.export import (
    BatchLogRecordProcessor,
)
 
from app.telemetry.resource import resource
from app.config.settings import Settings
 
_initialized = False
 
 
def configure_telemetry():
    """
    Configure OpenTelemetry exactly once.
    """
 
    global _initialized
 
    if _initialized:
        return
 
    #
    # Skip completely during tests
    #
 
    if Settings.TESTING:
        return
 
    if not Settings.ENABLE_TELEMETRY:
        return
 
    #
    # Trace Provider
    #
 
    trace_provider = TracerProvider(
        resource=resource
    )
 
    trace_provider.add_span_processor(
        BatchSpanProcessor(
            OTLPSpanExporter(
                endpoint=f"{Settings.OTEL_ENDPOINT}"
            )
        )
    )
 
    trace.set_tracer_provider(
        trace_provider
    )
 
    metric_reader = PeriodicExportingMetricReader(
        OTLPMetricExporter(
            endpoint=f"{Settings.OTEL_ENDPOINT}",
            insecure=True,
        )
    )
 
    metrics.set_meter_provider(
        MeterProvider(
            resource=resource,
            metric_readers=[metric_reader],
        )
    )

    logger_provider = LoggerProvider(
        resource=resource
    )
 
    logger_provider.add_log_record_processor(
        BatchLogRecordProcessor(
            OTLPLogExporter(
                endpoint=Settings.OTEL_ENDPOINT,
                insecure=True,
            )
        )
    )
 
    set_logger_provider(
        logger_provider
    )
 
    #
    # Attach OpenTelemetry LoggingHandler
    #
 
    otel_handler = LoggingHandler(
        logger_provider=logger_provider
    )
 
    root_logger = logging.getLogger()
 
    root_logger.setLevel(logging.INFO)
 
    if not any(
        isinstance(handler, LoggingHandler)
        for handler in root_logger.handlers
    ):
        root_logger.addHandler(
            otel_handler
        )
 
    _initialized = True
 
    logging.getLogger(__name__).info(
        "OpenTelemetry configured successfully."
    )